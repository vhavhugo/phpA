<?php

/**
 * @throws Exception
 */
function funcaoQueLancaExcecao()
{ }

function outraFuncao()
{
    funcaoQueLancaExcecao();
}
