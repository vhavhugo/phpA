<?php
//Silence is golden